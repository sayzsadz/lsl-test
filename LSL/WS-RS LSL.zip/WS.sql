select *
from user_ords_clients;

BEGIN
  oauth.create_client(p_name => 'Client 1',
                      p_grant_type       => 'client_credentials',
                      p_description      => 'Client with access to PO Resources',
                      p_support_email    => 'oracleebs@lankasathosa.org',
                      p_privilege_names  => NULL);
  COMMIT;
END;
/

--product
BEGIN
       
  ords.define_module(p_module_name    => 'lsl.v1',
                     p_base_path      => '/lsl/1',
                     p_items_per_page => 5,
                     p_status         => 'PUBLISHED',
                     p_comments       => 'lslmodule1 create store Module');             
  COMMIT;
END;
/

BEGIN
  ords.define_template(p_module_name => 'lsl.v1',
                       p_pattern     => 'products/',
                       p_comments    => 'lslmodule1 create store Module ');

  COMMIT;
END;
/

begin
  ORDS.define_handler(
    p_module_name    => 'lsl.v1',
    p_pattern        => 'products/',
    p_method         => 'POST',
    p_source_type    => ORDS.source_type_plsql,
    p_source         => '
                                        DECLARE
                                            l_response  VARCHAR2(32767);
                                            v_msg       VARCHAR2(50);
                                        BEGIN

                                            l_response := UTL_RAW.cast_to_varchar2(:body);
                                            check_product(l_response, v_msg);

                                            HTP.p(v_msg);

                                        EXCEPTION
                                          WHEN OTHERS THEN
                                            HTP.p(''405 Invalid Input'');
                                        END;',
    p_items_per_page => 0);

  COMMIT;
END;
/
--store
BEGIN
       
  ords.define_module(p_module_name    => 'lsl.v2',
                     p_base_path      => '/lsl/2',
                     p_items_per_page => 5,
                     p_status         => 'PUBLISHED',
                     p_comments       => 'lslmodule1 create store Module');             
  COMMIT;
END;
/

BEGIN
  ords.define_template(p_module_name => 'lsl.v2',
                       p_pattern     => 'stores/',
                       p_comments    => 'lslmodule1 create store Module ');

  COMMIT;
END;
/

begin
  ORDS.define_handler(
    p_module_name    => 'lsl.v2',
    p_pattern        => 'stores/',
    p_method         => 'POST',
    p_source_type    => ORDS.source_type_plsql,
    p_source         => 'DECLARE                            
                            v_msg VARCHAR2(1000);
                            l_response  VARCHAR2(32767);                      
                           BEGIN                             
                             -- Build response.
                             check_store(UTL_RAW.cast_to_varchar2(:body), v_msg);
                             l_response := v_msg;
 
                             -- Output response text.
                             HTP.p(l_response);
                             
                         END;',
    p_items_per_page => 0);

  COMMIT;
END;
/
--PR
BEGIN
       
  ords.define_module(p_module_name    => 'lsl.v3',
                     p_base_path      => 'lsl/3',
                     p_items_per_page => 5,
                     p_status         => 'PUBLISHED',
                     p_comments       => 'purchase request Module');             
  COMMIT;
END;
/
BEGIN
  ords.define_template(p_module_name => 'lsl.v3',
                       p_pattern     => 'purchase-request/',
                       p_comments    => 'purchase request template ');

  COMMIT;
END;
/
begin
  ORDS.define_handler(
    p_module_name    => 'lsl.v3',
    p_pattern        => 'purchase-request/',
    p_method         => 'POST',
    p_source_type    => ORDS.source_type_plsql,
    p_source         => 'DECLARE                            
                            v_msg VARCHAR2(1000);
                            l_response  VARCHAR2(32767);                      
                           BEGIN                             
                             -- Build response.
                             insert into xxpbsa_request (request, req_id) values (:body, xxpbsa_req_id.nextval);

                             commit;

                                select msg
                                into l_response
                                from xxpbsa_error_msg;

                             -- Output response text.
                             HTP.p(l_response);
                         END;',
    p_items_per_page => 0);

  COMMIT;
END;
/
--SR
BEGIN
       
  ords.define_module(p_module_name    => 'lsl.v4',
                     p_base_path      => 'lsl/4',
                     p_items_per_page => 5,
                     p_status         => 'PUBLISHED',
                     p_comments       => 'testmodule2 Module');             
  COMMIT;
END;
/
BEGIN
  ords.define_template(p_module_name => 'lsl.v4',
                       p_pattern     => 'supplier-return-requests/',
                       p_comments    => 'supplier return request ');

  COMMIT;
END;
/
begin
  ORDS.define_handler(
    p_module_name    => 'lsl.v4',
      p_pattern        => 'supplier-return-requests/',
    p_method         => 'POST',
    p_source_type    => ORDS.source_type_plsql,
    p_source         => 'DECLARE                            
                            v_msg VARCHAR2(1000);
                            l_response  VARCHAR2(32767);                      
                           BEGIN                             
                             -- Build response.
                             create_supplier_return(UTL_RAW.cast_to_varchar2(:body), v_msg);
                             l_response := v_msg;
 
                             -- Output response text.
                             HTP.p(l_response);
                             
                         END;',
    p_items_per_page => 0);

  COMMIT;
END;
/