SELECT *
FROM user_ords_schemas   uos,
     user_ords_modules   uom,
     user_ords_templates uot,
     user_ords_handlers  uoh
WHERE uot.module_id = uom.id
AND uom.schema_id = uos.id
AND uoh.template_id = uot.id
--AND uos.parsing_schema = 'ORDSDEMO'
ORDER BY uom.comments, uot.uri_template;

declare
p_data    varchar2(1000) := '{
  "StoreId": 123,
  "CompanyName": "Kohuwala",
  "Active": true
}';
p_msg  varchar2(1000);
BEGIN
check_store(p_data, p_msg);
END;
/

BEGIN
  ords.create_role(p_role_name => 'pbsa');
  COMMIT;
END;
/

DECLARE
  la_roles owa.vc_arr;
BEGIN
  la_roles(1) := 'pbsa';
  ords.define_privilege(p_privilege_name => 'pbsa.privilege',
                        p_roles          => la_roles,
                        p_label          => 'pbsa Access',
                        p_description    => 'Access to pbsa Web Services');
  COMMIT;
END;
/

DECLARE
  la_priv_patterns owa.vc_arr;
BEGIN
  la_priv_patterns(1) := '/*';
  ords.create_privilege_mapping(p_privilege_name => 'pbsa.privilege',
                                p_patterns       => la_priv_patterns);
  COMMIT;
END;
/

BEGIN
  oauth.grant_client_role(p_client_name => 'Client 1',
                          p_role_name   => 'pbsa');
  COMMIT;
END;
/


select *
from user_ords_client_roles;

select *
from USER_ORDS_PRIVILEGES;

select *
from USER_ORDS_PRIVILEGE_MAPPINGS;

select *
from USER_ORDS_CLIENT_ROLES;

DECLARE
  la_roles         owa.vc_arr;
  la_priv_patterns owa.vc_arr;
BEGIN
  --ords.create_role(p_role_name => 'pbsa');

  la_roles(1)         := 'pbsa';
  la_priv_patterns(1) := '/*';

  ords.define_privilege(p_privilege_name => 'pbsa.privilege',
                        p_roles          => la_roles,
                        p_patterns       => la_priv_patterns,
                        p_label          => 'PBSA Access',
                        p_description    => 'Access to PBSA Resources');
  COMMIT;
END;